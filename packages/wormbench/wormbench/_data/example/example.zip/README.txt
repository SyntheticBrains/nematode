64 wild-type PD1074 animals (OD 2) on Scheer & Bargmann's small lawn, band-cohort
rows only, from Scheer & Bargmann 2023 (Dryad doi:10.5061/dryad.47d7wm3jf, CC0-1.0).
Grade them with: wormbench grade --manifest manifest.txt --out grade.json
These animals are inside the bands they are graded against: the example shows how the
grader reads tracks, and validates nothing.
